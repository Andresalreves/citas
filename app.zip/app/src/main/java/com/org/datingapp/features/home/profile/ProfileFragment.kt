package com.org.datingapp.features.home.profile

import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.viewModels
import com.org.datingapp.core.platform.Event
import com.org.datingapp.databinding.FragmentProfileBinding
import com.org.datingapp.features.auth.User
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ProfileFragment : Fragment() {

    private var _binding : FragmentProfileBinding? = null
    private val binding get() = _binding!!

    private val getMyProfileViewModel by viewModels<GetMyProfileViewModel>()

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentProfileBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        getMyProfileViewModel.getProfile()
        getMyProfileViewModel.events.observe(viewLifecycleOwner, this::handleEvents)
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun renderUser(user : User) {

    }

    private fun handleEvents(event : Event<GetMyProfileViewModel.GetMyProfileViewModelNavigation>?) {
        event?.getContentIfNotHandled()?.let {  navigation ->
            when (navigation) {
                GetMyProfileViewModel.GetMyProfileViewModelNavigation.ShowGetMyProfileStart -> {
                    Log.d("TAG1", "Start")
                }
                is GetMyProfileViewModel.GetMyProfileViewModelNavigation.ShowGetMyProfileSuccess -> {
                    renderUser(navigation.user)
                }
                GetMyProfileViewModel.GetMyProfileViewModelNavigation.ShowServerError -> {
                    Log.d("TAG1", "Error")
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = ProfileFragment()
    }
}