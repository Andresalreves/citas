package com.org.datingapp.features.onboarding.interests

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import com.org.datingapp.R

class GetAllInterestsViewModel(application : Application) : AndroidViewModel(application) {

    private var _interests : List<InterestListItemViewModel>
    val interests get() = _interests

    init {
        val list = application.resources.getStringArray(R.array.interests).asList()
        _interests = list.map { InterestListItemViewModel(it, false) }
    }

}