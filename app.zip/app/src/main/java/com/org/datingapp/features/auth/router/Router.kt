package com.org.datingapp.features.auth.router

import com.org.datingapp.core.exception.Failure
import com.org.datingapp.core.functional.Either
import com.org.datingapp.core.interactor.UseCase
import com.org.datingapp.features.auth.Authenticator
import javax.inject.Inject

class Router @Inject constructor(private val authenticator: Authenticator) : UseCase<UseCase.None, UseCase.None>() {

    override suspend fun run(params: None): Either<Failure, None> {
        return if (authenticator.userLoggedIn()) {
            if (authenticator.profileComplete())
                Either.Right(None())
            else
                Either.Left(RouterFailure.UserProfileIncomplete())
        } else
            Either.Left(RouterFailure.UserNotLoggedIn())
    }

}
class RouterFailure {
    class UserNotLoggedIn() : Failure.FeatureFailure()
    class UserProfileIncomplete() : Failure.FeatureFailure()
}

