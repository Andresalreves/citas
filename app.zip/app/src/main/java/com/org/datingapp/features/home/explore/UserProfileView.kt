package com.org.datingapp.features.home.explore

import android.os.Parcel
import android.os.Parcelable
import androidx.annotation.Keep
import com.org.datingapp.features.BirthDateView

@Keep
data class UserProfileView (val id : String,
                            val fullName : String,
                            val birthDate : BirthDateView,
                            val gender : String,
                            val description : String?,
                            val profilePicture : String,
                            val pictures : List<String>,
                            val interests : List<String>) : Parcelable {


    constructor(parcel : Parcel) : this(
        parcel.readString()!!,
        parcel.readString()!!,
        parcel.readParcelable(BirthDateView::class.java.classLoader)!!,
        parcel.readString()!!,
        parcel.readString(),
        parcel.readString()!!,
        parcel.createStringArrayList()!!,
        parcel.createStringArrayList()!!
    ) {

    }

    override fun writeToParcel(parcel: Parcel, flags : Int) {
        parcel.writeString(id)
        parcel.writeString(fullName)
        parcel.writeParcelable(birthDate, flags)
        parcel.writeString(gender)
        parcel.writeString(description)
        parcel.writeString(profilePicture)
        parcel.writeStringList(interests)
    }

    override fun describeContents() = 0

    companion object CREATOR : Parcelable.Creator<UserProfileView> {
        override fun createFromParcel(parcel: Parcel): UserProfileView {
            return UserProfileView(parcel)
        }

        override fun newArray(size: Int): Array<UserProfileView?> {
            return arrayOfNulls(size)
        }
    }
}