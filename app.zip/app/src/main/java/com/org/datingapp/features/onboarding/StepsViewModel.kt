package com.org.datingapp.features.onboarding

import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import com.org.datingapp.core.platform.Event

class StepsViewModel : ViewModel() {

    private val numberOfSteps = 7

    private var _events = MutableLiveData<Event<Navigation>?>()
    val events : LiveData<Event<Navigation>?> get() = _events

    fun setStep(step : Int) {
        val progress = (step * 100) / numberOfSteps
        _events.value = Event(Navigation.ShowProgressChange(progress))
    }

    fun hideProgress() {
        _events.value = Event(Navigation.ShowHideProgress)
    }

    sealed class Navigation {
        object ShowHideProgress : Navigation()
        data class ShowProgressChange(val progress : Int) : Navigation()
    }
}