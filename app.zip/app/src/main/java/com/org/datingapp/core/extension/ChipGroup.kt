package com.org.datingapp.core.extension

import android.content.Context
import android.view.View
import com.google.android.material.chip.Chip
import com.google.android.material.chip.ChipGroup

fun ChipGroup.addChip(label : String, context : Context) {
    Chip(context).apply {
        id = View.generateViewId()
        text = label
        isClickable = true
        isCheckable = false
        isCheckedIconVisible = false
        addView(this)
    }
}