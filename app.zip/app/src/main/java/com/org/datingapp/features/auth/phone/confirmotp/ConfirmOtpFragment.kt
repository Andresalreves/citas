package com.org.datingapp.features.auth.phone.confirmotp

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.fragment.navArgs
import com.github.razir.progressbutton.*
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseAuthInvalidCredentialsException
import com.google.firebase.auth.PhoneAuthProvider
import com.org.datingapp.core.platform.LoadingViewModel
import com.org.datingapp.databinding.FragmentConfirmOtpBinding
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject
import com.org.datingapp.R

@AndroidEntryPoint
class ConfirmOtpFragment : Fragment() {

    private var _binding : FragmentConfirmOtpBinding? = null
    private val loadingViewModel by viewModels<LoadingViewModel>()
    private val binding get() = _binding!!
    private val args : ConfirmOtpFragmentArgs by navArgs()


    @Inject
    lateinit var firebaseAuth : FirebaseAuth

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentConfirmOtpBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.nextButton.isEnabled = binding.verificationCode.length() == 6
        binding.verificationCode.addTextChangedListener {
            binding.nextButton.isEnabled = binding.verificationCode.length() == 6
        }
        bindProgressButton(binding.nextButton)
        binding.nextButton.attachTextChangeAnimator {
            fadeInMills = 300
            fadeOutMills = 300
        }
        binding.backButton.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                requireActivity().onBackPressed()
            }
        }
        binding.nextButton.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                sendVerificationCode()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun sendVerificationCode() {
        loadingViewModel.isLoading = true
        showProgressButton()
        val verificationCode = binding.verificationCode.text.toString()
        val credential = PhoneAuthProvider.getCredential(args.verificationId, verificationCode)
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                handleSuccess()
            }
            else if (task.exception != null) {
                handleExceptions(task.exception!!)
            }
        }
    }

    private fun handleSuccess() {
        loadingViewModel.isLoading = false
        hideProgressButton()
        val action = ConfirmOtpFragmentDirections.actionConfirmOtpFragmentToMainNavigationGraph()
        findNavController().navigate(action)
    }

    private fun handleExceptions(exception : Exception) {
        exception.printStackTrace()
        Log.d("TAG1", exception.stackTraceToString())
        loadingViewModel.isLoading = false
        hideProgressButton()
        when (exception) {
            is FirebaseAuthInvalidCredentialsException -> {
                Toast.makeText(context, R.string.failure_sms_sign_in_invalid_code, Toast.LENGTH_LONG).show()
            }
            else ->  {
                Toast.makeText(context, R.string.failure_server_error, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun showProgressButton() {
        binding.nextButton.showProgress {
            progressColor = Color.WHITE
            gravity = DrawableButton.GRAVITY_CENTER
        }
    }

    private fun hideProgressButton() {
        binding.nextButton.hideProgress(R.string.action_next)
    }

    companion object {
        @JvmStatic
        fun newInstance() = ConfirmOtpFragment()
    }
}