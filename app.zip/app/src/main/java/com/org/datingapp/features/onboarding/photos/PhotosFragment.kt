package com.org.datingapp.features.onboarding.photos

import android.app.Activity.RESULT_OK
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.activityViewModels
import androidx.hilt.navigation.fragment.hiltNavGraphViewModels
import androidx.navigation.fragment.findNavController
import androidx.navigation.navGraphViewModels
import androidx.recyclerview.widget.GridLayoutManager
import com.org.datingapp.R
import com.org.datingapp.core.platform.Event
import com.org.datingapp.databinding.FragmentPhotosBinding
import com.org.datingapp.features.onboarding.StepsViewModel
import com.theartofdev.edmodo.cropper.CropImage
import dagger.hilt.android.AndroidEntryPoint


@AndroidEntryPoint
class PhotosFragment : Fragment()  {

    private var _binding  : FragmentPhotosBinding? = null
    private val binding get() = _binding!!

    private val photosViewModel by hiltNavGraphViewModels<PhotosViewModel>(R.id.on_boarding)
    private val optionsViewModel by navGraphViewModels<PhotosOptionsViewModel>(R.id.on_boarding)
    private val stepsViewModel by activityViewModels<StepsViewModel>()

    private val layoutManager by lazy {
        GridLayoutManager(requireActivity().applicationContext, 3)
    }
    private val adapter by lazy {
        PhotosAdapter({onAddPhotoClick()}, { position, localUri -> onPhotoClick(position, localUri) })
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentPhotosBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        stepsViewModel.setStep(7)
        binding.backButton.setOnClickListener {
            requireActivity().onBackPressed()
        }
        binding.nextButton.setOnClickListener {
            if (photosViewModel.isValid) {
                val action = PhotosFragmentDirections.actionPhotosFragmentToFinishFragment()
                findNavController().navigate(action)
                stepsViewModel.hideProgress()
            }
        }
        setPhotosRecycler()
        optionsViewModel.events.observe(viewLifecycleOwner, this::handleOptionsEvents)
        photosViewModel.events.observe(viewLifecycleOwner, this::handleEvents)
        photosViewModel.getPhotos()
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == CropImage.CROP_IMAGE_ACTIVITY_REQUEST_CODE) {
            val result = CropImage.getActivityResult(data)
            if (resultCode == RESULT_OK) {
                val resultUri: Uri = result.uri
                photosViewModel.photoUri = resultUri
                showUploadPhotoDialog()
            } else if (resultCode == CropImage.CROP_IMAGE_ACTIVITY_RESULT_ERROR_CODE) {
                val error = result.error
                Log.d("TAG1", error.toString())
            }
        }
    }

    private fun showUploadPhotoDialog() {
        val action = PhotosFragmentDirections.actionPhotosFragmentToUploadPhotoDialogFragment()
        findNavController().navigate(action)
    }

    private fun setPhotosRecycler() {
        binding.photosRecycler.adapter = adapter
        binding.photosRecycler.layoutManager = layoutManager
    }

    private fun refreshPhotosRecycler(localUris : List<Uri>) {
        adapter.refreshPhotos(localUris)
    }

    private fun onPhotoClick(position : Int, localUri : String) {
        val action = PhotosFragmentDirections.actionPhotosFragmentToPhotosBottomSheetDialogFragment(localUri, position)
        findNavController().navigate(action)
    }


    private fun startCropActivity() {
        CropImage
            .activity()
            .setCropMenuCropButtonTitle("SELECT")
            .setRequestedSize(640, 480)
            .start(requireContext(), this)
    }

    private fun onAddPhotoClick() {
        photosViewModel.option = PhotosViewModel.Options.Add
        startCropActivity()
    }

    private fun handleEvents(event : Event<PhotosViewModel.Navigation>?) {
        event?.getContentIfNotHandled()?.let { navigation ->
            when (navigation) {
                is PhotosViewModel.Navigation.ShowGetLocalUris -> {
                    refreshPhotosRecycler(navigation.localUris)
                }
            }
        }
    }

    private fun handleOptionsEvents(event : Event<PhotosOptionsViewModel.Navigation>?) {
        event?.getContentIfNotHandled()?.let { navigation ->
            when (navigation) {
                is PhotosOptionsViewModel.Navigation.ShowEditPhoto -> {
                    photosViewModel.option = PhotosViewModel.Options.Edit
                    photosViewModel.position = navigation.position
                    startCropActivity()
                }
                is PhotosOptionsViewModel.Navigation.ShowRemovePhoto -> {
                    photosViewModel.removePhoto(navigation.position)
                }
            }
        }
    }

    companion object {
        @JvmStatic
        fun newInstance() = PhotosFragment()
    }
}