package com.org.datingapp.features.onboarding.interests

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.datingapp.databinding.InterestRowBinding

class InterestAdapter(private val interests : List<InterestListItemViewModel>,
                      private val onInterestChecked : (interest : String) -> Unit,
                      private val onInterestUnchecked : (interest : String) -> Unit)
    : RecyclerView.Adapter<InterestAdapter.InterestViewHolder>(){


    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): InterestViewHolder {
        val binding = InterestRowBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return InterestViewHolder(binding, onInterestChecked, onInterestUnchecked)
    }

    override fun onBindViewHolder(holder: InterestViewHolder, position: Int) {
        val interest = interests[position]
        holder.bind(interest)
    }

    override fun getItemCount() = interests.size

    private fun unselectAll() =  interests.forEach { it.isSelected.set(false) }

    fun selectInterests(selectedInterests : HashSet<String>) {
        unselectAll()
        selectedInterests.forEach { selectedInterest ->
            val interest = this.interests.find { it.description == selectedInterest }
            interest?.isSelected?.set(true)
        }
    }

    class InterestViewHolder(private val binding : InterestRowBinding,
                             private val onInterestChecked: (interest: String) -> Unit,
                             private val onInterestUnchecked: (interest: String) -> Unit) : RecyclerView.ViewHolder(binding.root) {

        fun bind(interest : InterestListItemViewModel) {
            binding.vm = interest
            binding.root.setOnClickListener {
                val value = interest.isSelected.get() != true
                interest.isSelected.set(value)
                if (value)
                    onInterestChecked.invoke(interest.description)
                else
                    onInterestUnchecked.invoke(interest.description)
            }
        }
    }
}