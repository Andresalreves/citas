package com.org.datingapp.features.onboarding.photos

class PhotoOptions {

}