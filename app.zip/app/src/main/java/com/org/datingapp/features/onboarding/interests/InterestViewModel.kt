package com.org.datingapp.features.onboarding.interests

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class InterestViewModel  @Inject constructor() : ViewModel() {

    private var _interests =  hashSetOf<String>()

    var interests
    get() = _interests
    set (value) {
        _interests.clear()
        _interests.addAll(value)
    }

    val isValid get() = _interests.size >= Constants.MinNumberOfInterests

    val count get() = _interests.size

    fun addInterest(interest : String) {
        if (_interests.contains(interest))
            return
        _interests.add(interest)
    }

    fun removeInterest(interest : String) {
        if (!_interests.contains(interest))
            return
        _interests.remove(interest)
    }
}