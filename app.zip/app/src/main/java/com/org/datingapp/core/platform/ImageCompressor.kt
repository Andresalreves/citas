package com.org.datingapp.core.platform

import android.content.Context
import android.graphics.Bitmap
import dagger.hilt.android.qualifiers.ApplicationContext
import id.zelory.compressor.Compressor
import id.zelory.compressor.constraint.format
import id.zelory.compressor.constraint.quality
import id.zelory.compressor.constraint.resolution
import java.io.File
import javax.inject.Inject

class ImageCompressor @Inject constructor(@ApplicationContext private val context : Context){
    suspend fun compressImage(file : File) : File {
        return Compressor.compress(context, file) {
            resolution(640, 480)
            quality(70)
            format(Bitmap.CompressFormat.JPEG)
        }
    }
}