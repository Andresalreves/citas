package com.org.datingapp.core.di

import android.content.Context
import android.content.SharedPreferences
import dagger.Module
import dagger.Provides
import dagger.hilt.InstallIn
import dagger.hilt.components.SingletonComponent
import javax.inject.Singleton
import androidx.work.WorkManager
import com.google.gson.Gson
import com.org.datingapp.features.auth.Authenticator
import com.org.datingapp.features.onboarding.OnBoardingPreferencesManager
import com.org.datingapp.features.onboarding.photos.PhotoUploader
import com.org.datingapp.features.onboarding.birthdate.DateProvider
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Qualifier


@Qualifier
annotation class OnBoardingPreferences

@Module
@InstallIn(SingletonComponent::class)
object ApplicationModule {

    @OnBoardingPreferences
    @Provides
    @Singleton
    fun providesOnBoardingPreferences(@ApplicationContext context: Context) : SharedPreferences {
        return context.getSharedPreferences("dating-app-onBoarding-preferences" , Context.MODE_PRIVATE)
    }

    @Provides
    @Singleton
    fun providesWorkerManager(@ApplicationContext context : Context) = WorkManager.getInstance(context)

    @Provides
    @Singleton
    fun providesAuthenticator(authenticator : Authenticator.Firebase) : Authenticator = authenticator

    @Singleton
    @Provides
    fun providesOnBoardingPreferencesManager(preferences : OnBoardingPreferencesManager.Implementation) : OnBoardingPreferencesManager = preferences

    @Provides
    @Singleton
    fun providesDateProvider(dateProvider : DateProvider.Implementation) : DateProvider = dateProvider

    @Provides
    @Singleton
    fun providesPhotoUploader(photoUploader: PhotoUploader.Firebase) : PhotoUploader = photoUploader

    @Provides
    @Singleton
    fun providesGSON() = Gson()

}