package com.org.datingapp.features.auth

import java.util.*
import kotlin.collections.ArrayList


data class User(
    var id : String,
    var name : String,
    var normalizedName : String,
    var username : String,
    var normalizedUsername : String,
    var birthDate : BirthDate,
    var gender : String,
    var description : String? = null,
    var interests : List<String>,
    var profilePictureUris : List<String>,
    var timeStamp : Long = Date().time,
    var lastConnection : Long = 0L,
    var online : Boolean = false) {

    // Empty constructor required for serialization/deserialization
    constructor() : this(
        "",
        "",
        "",
        "",
        "",
        BirthDate(),
        "",
        "",
        ArrayList<String>(),
        ArrayList<String>())

    companion object {}
}


fun User.Companion.create(
    id : String,
    name : String,
    username: String,
    birthDate : BirthDate,
    gender : String,
    description : String?,
    interests: List<String>,
    profilePictureUris : List<String>) = User(
    id,
    name,
    name.lowercase(),
    username,
    username.lowercase(),
    birthDate,
    gender,
    description,
    interests,
    profilePictureUris)