package com.org.datingapp.features.home.explore

data class UserProfile(val name : String, val pictureUri : String) {}