package com.org.datingapp.features.onboarding.interests

import androidx.databinding.ObservableField


class InterestListItemViewModel constructor(desc : String, selected : Boolean)  {
    val description  = desc
    val isSelected = ObservableField(selected)
}


