package com.org.datingapp.features.onboarding.gender

import androidx.databinding.ObservableField

class GenderListItemViewModel constructor(desc : String, selected : Boolean)  {
    val description  = desc
    val checked = ObservableField(selected)
}


