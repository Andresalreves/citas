package com.org.datingapp.core.platform

import androidx.lifecycle.ViewModel

class LoadingViewModel : ViewModel() {
    var isLoading : Boolean = false
}