package com.org.datingapp.features.home.profile

import com.org.datingapp.core.exception.Failure
import com.org.datingapp.core.functional.Either
import com.org.datingapp.core.interactor.UseCase
import com.org.datingapp.features.auth.Authenticator
import com.org.datingapp.features.auth.User
import javax.inject.Inject

class GetMyProfile @Inject constructor(private val authenticator : Authenticator) : UseCase<User, UseCase.None>() {
    override suspend fun run(params: None): Either<Failure, User> = authenticator.getCurrentUser()
}