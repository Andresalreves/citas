package com.org.datingapp.features.onboarding.interests

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.activityViewModels
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.org.datingapp.R
import com.org.datingapp.core.platform.Event
import com.org.datingapp.databinding.FragmentInterestsBinding
import com.org.datingapp.features.onboarding.OnBoardingPreferencesManager
import com.org.datingapp.features.onboarding.StepsViewModel
import dagger.hilt.android.AndroidEntryPoint
import javax.inject.Inject

@AndroidEntryPoint
class InterestsFragment : Fragment() {

    private var _binding : FragmentInterestsBinding? = null
    private val binding get() = _binding!!

    private val getInterestViewModel by viewModels<GetAllInterestsViewModel>()
    private val interestViewModel by viewModels<InterestViewModel>()
    private val interestsPreferencesViewModel by viewModels<InterestsPreferencesViewModel>()
    private val stepsViewModel by activityViewModels<StepsViewModel>()
    private lateinit var adapter : InterestAdapter

    @Inject
    lateinit var onBoardingPreferences : OnBoardingPreferencesManager

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentInterestsBinding.inflate(inflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        stepsViewModel.setStep(6)

        binding.backButton.setOnClickListener {
            requireActivity().onBackPressed()
        }

        binding.nextButton.setOnClickListener {
            if (interestViewModel.isValid) {
                interestsPreferencesViewModel.storeInterests(interestViewModel.interests)
            }
        }
        interestsPreferencesViewModel.events.observe(viewLifecycleOwner, this::handlePreferenceEvents)

        interestsPreferencesViewModel.getInterests()
    }

    private fun setInterestsLists(interests : HashSet<String>) {
        val layoutManager = LinearLayoutManager(activity?.applicationContext)
        adapter = InterestAdapter(
            getInterestViewModel.interests,
            {interest -> onInterestChecked(interest)} ,
            {interest -> onInterestUnchecked(interest)})

        binding.interestsRecycler.adapter = adapter
        binding.interestsRecycler.layoutManager = layoutManager

        val dividerItemDecorator = DividerItemDecoration(
            binding.interestsRecycler.context,
            layoutManager.orientation
        )
        binding.interestsRecycler.addItemDecoration(dividerItemDecorator)
        adapter.selectInterests(interests)
    }

    private fun onInterestChecked(interest : String) {
        interestViewModel.addInterest(interest)
        changeButtonState(interestViewModel.count, interestViewModel.isValid)
    }

    private fun onInterestUnchecked(interest : String) {
        interestViewModel.removeInterest(interest)
        changeButtonState(interestViewModel.count, interestViewModel.isValid)
    }

    private fun handlePreferenceEvents(event : Event<InterestsPreferencesViewModel.Navigation>?) {
        event?.getContentIfNotHandled()?.let { navigation ->
            when (navigation) {
                is InterestsPreferencesViewModel.Navigation.ShowGetInterests -> {
                    interestViewModel.interests = navigation.interests
                    setInterestsLists(navigation.interests)
                    changeButtonState(interestViewModel.count, interestViewModel.isValid)
                }
                InterestsPreferencesViewModel.Navigation.ShowStoreInterests -> {
                    val action = InterestsFragmentDirections.actionInterestsFragmentToPhotosFragment()
                    findNavController().navigate(action)
                }
            }
        }
    }

    private fun changeButtonState(count : Int, isModelValid : Boolean) {
        if (!isModelValid)
        {
            binding.nextButton.isEnabled = false
            binding.nextButton.text = getString(R.string.action_select)
        }
        else {
            binding.nextButton.isEnabled = true
            binding.nextButton.text = "${getString(R.string.action_select)} $count"
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        @JvmStatic
        fun newInstance() = InterestsFragment()
    }
}