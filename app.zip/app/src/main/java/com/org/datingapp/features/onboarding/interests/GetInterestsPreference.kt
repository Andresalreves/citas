package com.org.datingapp.features.onboarding.interests

import com.org.datingapp.core.exception.Failure
import com.org.datingapp.core.functional.Either
import com.org.datingapp.core.interactor.UseCase
import com.org.datingapp.features.onboarding.OnBoardingPreferencesManager
import javax.inject.Inject

class GetInterestsPreference @Inject constructor(private val preferencesManager: OnBoardingPreferencesManager) : UseCase<HashSet<String>, UseCase.None> () {
    override suspend fun run(params: None): Either<Failure, HashSet<String>> {
        val interest = preferencesManager.interests
        return Either.Right(interest)
    }
}