package com.org.datingapp.features.home.explore

import com.google.firebase.firestore.CollectionReference
import com.org.datingapp.core.di.UserCollection
import kotlinx.coroutines.flow.Flow
import javax.inject.Inject

interface UserProfilesRepository {

    fun getUserProfiles() : Flow<List<UserProfile>>
    fun getUserProfileById(id : String) : Flow<UserProfile>

    class Network @Inject constructor(  @UserCollection
                                        private val userCollection : CollectionReference
    ) : UserProfilesRepository {

        override fun getUserProfiles(): Flow<List<UserProfile>> {
            TODO("Not yet implemented")
        }

        override fun getUserProfileById(id: String): Flow<UserProfile> {
            TODO("Not yet implemented")
        }
    }
}