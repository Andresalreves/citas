package com.org.datingapp.features.onboarding

import android.content.SharedPreferences
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.org.datingapp.core.di.OnBoardingPreferences
import com.org.datingapp.features.auth.BirthDate
import com.org.datingapp.features.onboarding.photos.Photo
import javax.inject.Inject

interface OnBoardingPreferencesManager {

    var name : String
    var birthDate : BirthDate
    var gender: String
    var username : String
    var description : String
    var interests : HashSet<String>
    var photos : MutableList<Photo>

    fun clearPreferences()

    class Implementation @Inject constructor(@OnBoardingPreferences
                                                           private val sharedPreferences : SharedPreferences,
                                                           private val gson : Gson) :
        OnBoardingPreferencesManager {

        override var name : String
            get() = sharedPreferences.getString(fullNameKey, null) ?: ""
            set (value) {
                with (sharedPreferences.edit()) {
                    putString(fullNameKey, value)
                    apply()
                }
            }

        override var birthDate : BirthDate
            get() {
                val json = sharedPreferences.getString(birthDateKey, null) ?: return BirthDate.empty()
                return gson.fromJson(json, BirthDate::class.java)
            }
            set (value) {
                with(sharedPreferences.edit()) {
                    putString(birthDateKey, gson.toJson(value))
                    apply()
                }
            }

        override var gender: String
            get() = sharedPreferences.getString(genderKey, null) ?: ""
            set(value) {
                with(sharedPreferences.edit()) {
                    putString(genderKey, value)
                    apply()
                }
            }

        override var username : String
            get() = sharedPreferences.getString(usernameKey, null) ?: ""
            set (value) {
                with (sharedPreferences.edit()) {
                    putString(usernameKey, value)
                    apply()
                }
            }

        override var description : String
            get() = sharedPreferences.getString(descriptionKey, null) ?: ""
            set(value) {
                with(sharedPreferences.edit()) {
                    putString(descriptionKey, value)
                    apply()
                }
            }

        override var interests : HashSet<String>
            get() = sharedPreferences.getStringSet(interestsKey, hashSetOf<String>()) as HashSet<String>
            set (value) {
                with (sharedPreferences.edit()) {
                    putStringSet(interestsKey, value)
                    apply()
                }
            }

        override var photos : MutableList<Photo>
            get() {
                val json = sharedPreferences.getString(photosKey, null) ?: return mutableListOf()
                val itemType = object : TypeToken<MutableList<Photo>>() {}.type
                return gson.fromJson(json, itemType)
            }
            set (value) {
                with(sharedPreferences.edit()) {
                    putString(photosKey, gson.toJson(value))
                    apply()
                }
            }

        override fun clearPreferences() {
            with (sharedPreferences.edit()) {
                clear()
                apply()
            }
        }

        companion object {
            const val fullNameKey = "fullName-key"
            const val birthDateKey = "birthDate-key"
            const val genderKey = "gender-key"
            const val usernameKey = "username-key"
            const val photosKey = "photos-key"
            const val descriptionKey = "description-key"
            const val interestsKey = "interests-key"
        }
    }
}

