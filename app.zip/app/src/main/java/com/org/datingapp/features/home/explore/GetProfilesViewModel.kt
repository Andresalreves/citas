package com.org.datingapp.features.home.explore

import androidx.lifecycle.ViewModel
import dagger.hilt.android.lifecycle.HiltViewModel
import javax.inject.Inject

@HiltViewModel
class GetProfilesViewModel @Inject constructor(private val getUserProfile: GetProfiles) : ViewModel() {


    fun getProfiles() {

    }

    sealed class GetUserProfilesViewModelNavigation {
        object ShowGetUserProfilesStart : GetUserProfilesViewModelNavigation()
        data class ShowGetUserProfilesSuccess(val userProfiles : List<UserProfileView>) : GetUserProfilesViewModelNavigation()

    }
}