package com.org.datingapp.features.home.explore

import javax.inject.Inject

class GetProfiles @Inject constructor() {

}