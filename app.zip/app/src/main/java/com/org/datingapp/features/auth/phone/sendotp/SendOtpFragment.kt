package com.org.datingapp.features.auth.phone.sendotp

import android.content.ActivityNotFoundException
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.core.widget.addTextChangedListener
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.github.razir.progressbutton.*
import com.google.firebase.FirebaseException
import com.google.firebase.FirebaseTooManyRequestsException
import com.google.firebase.auth.*
import com.org.datingapp.databinding.FragmentSendOtpBinding
import com.org.datingapp.core.platform.LoadingViewModel
import com.org.datingapp.R
import dagger.hilt.android.AndroidEntryPoint
import java.util.concurrent.TimeUnit
import javax.inject.Inject

@AndroidEntryPoint
class SendOtpFragment : Fragment() {

    private val loadingViewModel by viewModels<LoadingViewModel>()

    private var _binding : FragmentSendOtpBinding? = null
    private val binding get() = _binding!!

    @Inject
    lateinit var firebaseAuth : FirebaseAuth

    private val callbacks = object : PhoneAuthProvider.OnVerificationStateChangedCallbacks() {
        override fun onVerificationCompleted(credential: PhoneAuthCredential) {
            signInWithCredentials(credential)
        }

        override fun onVerificationFailed(exception: FirebaseException) {
            handleExceptions(exception)
        }

        override fun onCodeSent(verificationId : String, token: PhoneAuthProvider.ForceResendingToken) {
            super.onCodeSent(verificationId, token)
            handleCodeSent(verificationId)
        }
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentSendOtpBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        binding.countryCodePicker.registerCarrierNumberEditText(binding.cellPhone)
        binding.nextButton.isEnabled = binding.countryCodePicker.isValidFullNumber
        binding.cellPhone.addTextChangedListener {
            binding.nextButton.isEnabled = binding.countryCodePicker.isValidFullNumber
        }
        bindProgressButton(binding.nextButton)
        binding.nextButton.attachTextChangeAnimator {
            fadeInMills = 300
            fadeOutMills = 300
        }
        binding.backButton.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                requireActivity().onBackPressed()
            }
        }
        binding.nextButton.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                sendVerificationCode()
            }
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun sendVerificationCode() {
        if (binding.countryCodePicker.isValidFullNumber) {
            loadingViewModel.isLoading = true
            showProgressButton()
            val phoneNumber = binding.countryCodePicker.fullNumberWithPlus
            val options = PhoneAuthOptions.newBuilder(firebaseAuth)
                .setPhoneNumber(phoneNumber)
                .setTimeout(60L, TimeUnit.SECONDS)
                .setActivity(requireActivity())
                .setCallbacks(callbacks)
                .build()
            PhoneAuthProvider.verifyPhoneNumber(options)
        }
    }

    private fun signInWithCredentials(credentials : PhoneAuthCredential) {
        firebaseAuth
            .signInWithCredential(credentials)
            .addOnCompleteListener { task->
                if (task.isSuccessful) {
                    handleSuccess()
                }
                else if (task.exception != null) {
                    handleExceptions(task.exception!!)
                }
            }
    }

    private fun handleExceptions(exception : Exception) {
        Log.e("TAG1", exception.stackTraceToString())
        exception.stackTrace
        loadingViewModel.isLoading = false
        hideProgressButton()
        when (exception) {
            is FirebaseAuthInvalidCredentialsException -> {
                Toast.makeText(context, R.string.failure_sms_sign_in, Toast.LENGTH_LONG).show()
            }
            is FirebaseTooManyRequestsException -> {
                Toast.makeText(context, R.string.failure_sign_in_too_many_requests, Toast.LENGTH_LONG).show()
            }
            is ActivityNotFoundException -> {
                Toast.makeText(context,"Error : Es necesario un navegador web habilitado para completar este paso.", Toast.LENGTH_LONG).show()
            }
            else -> {
                Toast.makeText(context, R.string.failure_server_error, Toast.LENGTH_LONG).show()
            }
        }
    }

    private fun handleSuccess() {
        loadingViewModel.isLoading = false
        hideProgressButton()
        val action = SendOtpFragmentDirections.actionSendOtpFragmentToMainNavigationGraph()
        findNavController().navigate(action)
    }

    private fun handleCodeSent(verificationId : String) {
        loadingViewModel.isLoading = false
        hideProgressButton()
        val action = SendOtpFragmentDirections.actionSendOtpFragmentToConfirmOtpFragment(verificationId)
        findNavController().navigate(action)
    }

    private fun showProgressButton() {
        binding.nextButton.showProgress {
            progressColor = Color.WHITE
            gravity = DrawableButton.GRAVITY_CENTER
        }
    }

    private fun hideProgressButton() {
        binding.nextButton.hideProgress(R.string.action_next)
    }

    companion object {
        @JvmStatic
        fun newInstance() = SendOtpFragment()
    }
}