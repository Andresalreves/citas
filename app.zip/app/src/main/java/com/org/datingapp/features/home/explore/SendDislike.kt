package com.org.datingapp.features.home.explore

class SendDislike {
}