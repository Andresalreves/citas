package com.org.datingapp.features.onboarding.photos

import android.net.Uri
import com.google.android.gms.tasks.Task
import com.google.firebase.storage.StorageReference
import com.google.firebase.storage.ktx.storageMetadata
import com.org.datingapp.core.di.UserStorage
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.*
import javax.inject.Inject

interface PhotoUploader {

    suspend fun upload(uri : Uri) : String

    class Firebase @Inject constructor(@UserStorage
                                       private val userStorage : StorageReference) : PhotoUploader {


        private fun buildUploadPhotoTask(photoUri : Uri) : Task<Uri> {

            val uuid = UUID.randomUUID().toString()


            val metadata = storageMetadata {
                contentType = "image/jpg"
            }

            val newStorageRef = userStorage
                .child("${uuid}.jpg")

            val uploadTask = newStorageRef.putFile(photoUri, metadata)

            return uploadTask.continueWithTask { task ->
                if (!task.isSuccessful) {
                    task.exception?.let {
                        throw it
                    }
                }
                newStorageRef.downloadUrl
            }

        }

        override suspend fun upload(uri: Uri): String {
            return withContext(Dispatchers.IO) {
                val downloadUriTask = buildUploadPhotoTask(uri)
                downloadUriTask.await().toString()
            }
        }

    }
}
