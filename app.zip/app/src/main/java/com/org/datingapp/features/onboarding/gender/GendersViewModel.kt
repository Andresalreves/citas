package com.org.datingapp.features.onboarding.gender

import android.content.Context
import android.text.TextUtils
import androidx.lifecycle.ViewModel
import com.org.datingapp.R
import dagger.hilt.android.lifecycle.HiltViewModel
import dagger.hilt.android.qualifiers.ApplicationContext
import javax.inject.Inject

@HiltViewModel
class GendersViewModel @Inject constructor(@ApplicationContext context : Context) : ViewModel() {

    private var _genders : List<GenderListItemViewModel>
    val genders get() = _genders

    init {
        val list = context.resources.getStringArray(R.array.genres).asList()
        _genders = list.map {GenderListItemViewModel(it, false)}
    }

    private var _gender = ""

    var gender : String
    get() = _gender
    set (value) {
        _gender = value
    }

    val isValid get() = !TextUtils.isEmpty(_gender)


}