package com.org.datingapp.features.onboarding.finish

import com.org.datingapp.core.exception.Failure
import com.org.datingapp.core.functional.Either
import com.org.datingapp.core.interactor.UseCase
import com.org.datingapp.features.auth.Authenticator
import com.org.datingapp.features.auth.User
import com.org.datingapp.features.auth.create
import com.org.datingapp.features.onboarding.OnBoardingPreferencesManager
import javax.inject.Inject

class Finish @Inject constructor(private val preferencesManager: OnBoardingPreferencesManager,
                                 private val authenticator: Authenticator) : UseCase<UseCase.None, UseCase.None>() {
    override suspend fun run(params: None): Either<Failure, None> {
        val user = User.create(
            authenticator.userId(),
            preferencesManager.name,
            preferencesManager.username,
            preferencesManager.birthDate,
            preferencesManager.gender,
            preferencesManager.description,
            preferencesManager.interests.toList(),
            preferencesManager.photos.map { p -> p.remoteUri })

        val result = authenticator.completeProfile(user)
        preferencesManager.clearPreferences()
        return result
    }
}