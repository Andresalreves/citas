package com.org.datingapp.features.home.explore

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.view.animation.AccelerateInterpolator
import android.view.animation.LinearInterpolator
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.DefaultItemAnimator
import com.google.android.material.floatingactionbutton.FloatingActionButton
import com.org.datingapp.databinding.FragmentExploreBinding
import com.yuyakaido.android.cardstackview.*
import dagger.hilt.android.AndroidEntryPoint

@AndroidEntryPoint
class ExploreFragment : Fragment(), CardStackListener {

    private var _binding : FragmentExploreBinding? = null
    private val binding get() = _binding!!

    private lateinit var manager : CardStackLayoutManager
    private lateinit var adapter : UserProfilesStackAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentExploreBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        initialize()

        binding.likeFba.setOnClickListener {
            animateFab(binding.likeFba)
            val settings = SwipeAnimationSetting.Builder()
                .setDirection(Direction.Right)
                .setDuration(Duration.Normal.duration)
                .setInterpolator(AccelerateInterpolator())
                .build()
            manager.setSwipeAnimationSetting(settings)
            binding.cardStackView.swipe()
        }

        binding.dislikeFba.setOnClickListener {
            animateFab(binding.dislikeFba)
            val settings = SwipeAnimationSetting.Builder()
                .setDirection(Direction.Left)
                .setDuration(Duration.Normal.duration)
                .setInterpolator(AccelerateInterpolator())
                .build()
            manager.setSwipeAnimationSetting(settings)
            binding.cardStackView.swipe()
        }
    }

    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    companion object {
        @JvmStatic
        fun newInstance() = ExploreFragment()
    }

    private fun animateFab(fab: FloatingActionButton) {
        fab.animate().scaleX(0.7f).setDuration(100).withEndAction {
            fab.animate().scaleX(1f).scaleY(1f)
        }
    }

    private fun initialize() {
        manager = CardStackLayoutManager(context, this)
        adapter = UserProfilesStackAdapter(getProfiles())
        manager.setStackFrom(StackFrom.None)
        manager.setVisibleCount(3)
        manager.setTranslationInterval(8.0f)
        manager.setScaleInterval(0.95f)
        manager.setSwipeThreshold(0.3f)
        manager.setMaxDegree(20.0f)
        manager.setDirections(Direction.HORIZONTAL)
        manager.setCanScrollHorizontal(true)
        manager.setCanScrollVertical(false)
        manager.setSwipeableMethod(SwipeableMethod.AutomaticAndManual)
        manager.setOverlayInterpolator(LinearInterpolator())
        binding.cardStackView.layoutManager = manager
        binding.cardStackView.adapter = adapter
        binding.cardStackView.itemAnimator.apply {
            if (this is DefaultItemAnimator) {
                supportsChangeAnimations = false
            }
        }
    }

    override fun onCardDragging(direction: Direction?, ratio: Float) {
        Log.d("CardStackView", "onCardDragging: d = ${direction?.name}, r = $ratio")
    }

    override fun onCardSwiped(direction: Direction?) {

    }


    private fun handleSwipeEvents() {

    }

    private fun handleMatchEvents() {

    }


    override fun onCardRewound() {
        Log.d("CardStackView", "onCardRewound: ${manager.topPosition}")
    }

    override fun onCardCanceled() {
        Log.d("CardStackView", "onCardCanceled: ${manager.topPosition}")
    }

    override fun onCardAppeared(view: View?, position: Int) {
        Log.d("CardStackView", "onCardAppeared: ($position)")
    }

    override fun onCardDisappeared(view: View?, position: Int) {
        Log.d("CardStackView", "onCardDisappeared: ($position)")
    }

    private fun getProfiles() : List<UserProfile> {
        return mutableListOf(
            UserProfile("Saitama", "https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg"),
            UserProfile("Deku", "https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-midoriya-x-uraraka-29-1024x678.jpg"),
            UserProfile("Saitama", "https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg"),
            UserProfile("Deku", "https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-midoriya-x-uraraka-29-1024x678.jpg"),
            UserProfile("Saitama", "https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg"),
            UserProfile("Deku", "https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-midoriya-x-uraraka-29-1024x678.jpg"),
            UserProfile("Saitama", "https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg"),
            UserProfile("Deku", "https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-midoriya-x-uraraka-29-1024x678.jpg"),
            UserProfile("Saitama", "https://img.mipon.org/wp-content/uploads/2019/04/05164321/saitama-one-punch-man-oppai-shirt1-1024x569.jpg"),
            UserProfile("Deku", "https://aniyuki.com/wp-content/uploads/2021/07/aniyuki-midoriya-x-uraraka-29-1024x678.jpg")
        )
    }
}