package com.org.datingapp.features.auth.google

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.util.Log
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.viewModels
import androidx.navigation.fragment.findNavController
import com.github.razir.progressbutton.*
import com.google.android.gms.auth.api.signin.GoogleSignIn
import com.google.android.gms.auth.api.signin.GoogleSignInClient
import com.google.android.gms.auth.api.signin.GoogleSignInOptions
import com.google.android.gms.common.api.ApiException
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import com.org.datingapp.core.platform.LoadingViewModel
import com.org.datingapp.databinding.FragmentGoogleAuthBinding
import dagger.hilt.android.AndroidEntryPoint
import java.lang.Exception
import javax.inject.Inject
import com.org.datingapp.R

/***
 * Google Sign In Kotlin by MoureDev by Brais Moure
 * https://www.youtube.com/watch?v=xjsgRe7FTCU
 * apartir del minuto 15:34 para configurar la consola de google
 * **/
@AndroidEntryPoint
class GoogleAuthFragment : Fragment() {


    private val loadingViewModel by viewModels<LoadingViewModel>()

    private var _binding : FragmentGoogleAuthBinding? = null
    private val binding get() = _binding!!

    @Inject
    lateinit var firebaseAuth : FirebaseAuth
    private lateinit var googleSignInClient  : GoogleSignInClient


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val gso = GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
            .requestIdToken(getString(R.string.default_web_client_id))
            .requestEmail()
            .build()

        googleSignInClient = GoogleSignIn.getClient(requireActivity(), gso)
    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        _binding = FragmentGoogleAuthBinding.inflate(layoutInflater, container, false)
        return binding.root
    }

    override fun onViewCreated(view: View, savedInstanceState: Bundle?) {
        super.onViewCreated(view, savedInstanceState)
        bindProgressButton(binding.googleSignIn)
        binding.googleSignIn.attachTextChangeAnimator {
            fadeInMills = 300
            fadeOutMills = 300
        }
        binding.backButton.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                requireActivity().onBackPressed()
            }
        }

        binding.googleSignIn.setOnClickListener {
            if (!loadingViewModel.isLoading) {
                signIn()
            }
        }

    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)

        // Result returned from launching the Intent from GoogleSignInApi.getSignInIntent(...);
        if (requestCode == RC_SIGN_IN) {
            val task = GoogleSignIn.getSignedInAccountFromIntent(data)
            try {
                // Google Sign In was successful, authenticate with Firebase
                val account = task.getResult(ApiException::class.java)!!
                Log.d(TAG, "firebaseAuthWithGoogle:" + account.id)
                firebaseAuthWithGoogle(account.idToken!!)
            } catch (e: ApiException) {
                handleExceptions(e)
            }
        }
    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding = null
    }

    private fun signIn() {
        loadingViewModel.isLoading = true
        showProgressButton()
        val signInIntent = googleSignInClient.signInIntent
        startActivityForResult(signInIntent, RC_SIGN_IN)
    }

    private fun firebaseAuthWithGoogle(idToken : String) {
        val credential = GoogleAuthProvider.getCredential(idToken, null)
        firebaseAuth.signInWithCredential(credential).addOnCompleteListener { task ->
            if (task.isSuccessful) {
                handleSuccess()
            }
            else if (task.exception != null){
                handleExceptions(task.exception!!)
            }
        }
    }

    private fun handleSuccess() {
        val action = GoogleAuthFragmentDirections.actionGoogleAuthFragmentToMainNavigationGraph()
        findNavController().navigate(action)
    }

    private fun handleExceptions(exception : Exception) {
        exception.printStackTrace()
        loadingViewModel.isLoading = false
        hideProgressButton()
        Toast.makeText(context, R.string.failure_server_error, Toast.LENGTH_LONG).show()
    }

    private fun showProgressButton() {
        binding.googleSignIn.showProgress {
            progressColor = Color.WHITE
            gravity = DrawableButton.GRAVITY_CENTER
        }
    }

    private fun hideProgressButton() {
        binding.googleSignIn.hideProgress(R.string.label_sign_in_with_google)
    }

    companion object {
        private const val TAG = "GoogleAuthFragment"
        private const val RC_SIGN_IN = 9001
        @JvmStatic
        fun newInstance() = GoogleAuthFragment()
    }
}