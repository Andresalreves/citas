package com.org.datingapp.features.home.explore

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.datingapp.databinding.ProfileCardBinding
import com.squareup.picasso.Picasso

class ProfilesAdapter(private val profiles : List<UserProfile>) : RecyclerView.Adapter<ProfilesAdapter.ProfileViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ProfileViewHolder {
        val binding = ProfileCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ProfileViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ProfileViewHolder, position: Int) {
        val profile = profiles[position]
        holder.bind(profile)
    }

    override fun getItemCount() = profiles.size

    inner class ProfileViewHolder(private val binding : ProfileCardBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(userProfile : UserProfile) {
            binding.profileName.text = userProfile.name
            Picasso.get().load(userProfile.pictureUri).into(binding.profileImage)
        }
    }
}