package com.org.datingapp.features.home.explore

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.org.datingapp.databinding.ProfileCardBinding
import com.squareup.picasso.Picasso

class UserProfilesStackAdapter (private var userProfiles : List<UserProfile>) : RecyclerView.Adapter<UserProfilesStackAdapter.ViewHolder>() {



    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ProfileCardBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val profile = profiles[position]
        holder.bind(profile)
    }

    override fun getItemCount() = profiles.size

    val profiles get() = userProfiles


    inner class ViewHolder(private val binding : ProfileCardBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(profile : UserProfile) {
            binding.profileName.text = profile.name
            Picasso.get().load(profile.pictureUri).into(binding.profileImage)
            binding.profileDistance.text = "0 miles away"
        }
    }


}